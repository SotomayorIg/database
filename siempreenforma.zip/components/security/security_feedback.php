<?php

class SecurityFeedback
{
    const Positive = 'security_feedback_positive';
    const Negative = 'security_feedback_negative';
}
